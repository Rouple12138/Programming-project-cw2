#include <stdio.h>
#include "Game.h"

int main(){
    int loop = 0;
    int option = 0;
    printf("Please choose an option: \n");
    printf("1) Display the game \n");
    printf("2) Decide the number of generations \n");
    printf("3) Change the size of the world \n");
    scanf("%d", &option);
    getchar();
    switch (option) {
        case 1: {
            initialize();
            while(1){
                if (SDL_PollEvent(&event)) {
                    if (event.type == SDL_QUIT) {
                        return 0;
                    }
                }
                RenderScreen();
                SDL_Delay(50);
            }
        }
        case 2: {
            printf("Please enter the number of generation: \n");
            scanf("%d", &loop);
            getchar();
            initialize();
            for (int i = 0; i < loop; ++i) {
                RenderScreen();
                SDL_Delay(500);
            }
            break;
        }
        case 3: {
            printf("Please enter the size of the world: (200 - 764)");
            scanf("%d", &windowSize);
            getchar();
        }
    }
}