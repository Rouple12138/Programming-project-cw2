#include "unity.h"
#include "Game.h"


void test_CreateBackup() {
    CreateBackup();
    TEST_ASSERT(CurrentCells[34][45] == cells[34][45]);
}

void test_CountAroundCells(){
    TEST_ASSERT(CountAroundCells(34,45) >= 0 && CountAroundCells(34,45) <= 8);
}

void test_PlaceOnFile(){
    FILE * fp;
    fp = fopen("memory.txt", "r");
    TEST_ASSERT_NOT_NULL (fp);
}

void test_RandomGenerateCells(){
    RandomGenerateCells();
    TEST_ASSERT(cells[34][45] == 0 || cells[34][45] == 1);
}

void setUp(){

}
void tearDown(){

}

int main() {
  UNITY_BEGIN();
  RUN_TEST(test_CountAroundCells);


  return UNITY_END();
}
