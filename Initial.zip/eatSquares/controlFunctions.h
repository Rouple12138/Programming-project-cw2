
void init(void);
void input(void);
bool update(void);
void gameover(void);
void render(void);

